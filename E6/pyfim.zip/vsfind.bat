@echo off
setlocal enabledelayedexpansion

echo Scanning system for Visual Studio installations...
echo --------------------------------------------------

:: Locate the official Microsoft VS discovery tool
set "vswhere=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"

if not exist "%vswhere%" (
    echo [ERROR] Microsoft vswhere.exe not found. 
    echo Please ensure Visual Studio is properly installed.
    goto :end
)

:: Find the main version number (e.g., 15.x, 16.x, 17.x, 18.x)
for /f "usebackq tokens=*" %%i in (`"%vswhere%" -latest -property installationVersion`) do (
    set "FULL_VERSION=%%i"
)

:: Find the installation path
for /f "usebackq tokens=*" %%i in (`"%vswhere%" -latest -property installationPath`) do (
    set "VS_PATH=%%i"
)

if not defined FULL_VERSION (
    echo [ERROR] No Visual Studio installation could be detected.
    goto :end
)

:: Extract the major version number (the digits before the first dot)
for /f "tokens=1 delims=." %%a in ("%FULL_VERSION%") do (
    set "MAJOR_VERSION=%%a"
)

:: Construct the proper environment variable name
set "VAR_NAME=VS!MAJOR_VERSION!0COMNTOOLS"
set "TOOLS_PATH=!VS_PATH!\Common7\Tools\"

:: Output the dynamically generated configuration
echo [FOUND] Active Version: %FULL_VERSION%
echo [FOUND] Target Variable Name: %VAR_NAME%
echo [FOUND] Tools Directory Path: %TOOLS_PATH%
echo.
echo :: Setting variable locally for this session...
set "%VAR_NAME%=%TOOLS_PATH%"
echo Success. %%!VAR_NAME!%% is now ready to use.

:end
echo --------------------------------------------------
pause
